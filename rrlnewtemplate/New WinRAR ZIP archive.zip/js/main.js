 $(document).ready(function(){
    $(".top_header").sticky({topSpacing:0});
  });