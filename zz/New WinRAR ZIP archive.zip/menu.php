		<nav id="nav">
						<ul>
							<li><a href="index.php">Home</a></li>
							<!--<li>
								<a href="">Herbs</a>
								<ul>
									<li><a href="cayenne.html">Cayenne</a></li>
									<li><a href="cinnamon.html">Cinnamon</a></li>
									<li><a href="ginger.html">Ginger</a></li>
				                                        <li><a href="ginseng.html">Ginseng</a></li>
									<li><a href="milkthistle.html">Milk Thistle</a></li>
									<li><a href="lecithin.html">Lecithin</a></li>
								</ul>
							</li>-->
							<li><a href="cart.php">Cart</a></li>
							<li><a href="soap.php">Soap</a></li>
							<li><a href="necklace.php">Oil Necklace</a></li>
							<li><a href="contact-us.php">Contact</a></li>


						</ul>
						</ul>
					</nav>