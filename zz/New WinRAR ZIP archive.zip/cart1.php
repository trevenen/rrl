<!DOCTYPE HTML>
<html>
	<head>
	<?php include 'header.php'
	?>
		
				<!-- Nav -->
						
<?php include 'menu.php'
	?>
		
			</div>
			
		<!-- Main -->
<div class="bodys">
			<div class="wrapper style1">

				<div class="container">
					      <div class="row">


        <!-- begin:content -->
        <div class="col-md-9 col-sm-8 content">
          <div class="row">
           <!-- <div class="col-md-12">
                <ol class="breadcrumb">
                  <li><a href="#">Home</a></li>
                  <li><a href="#">Girl</a></li>
                  <li><a href="#">Pants</a></li>
                  <li class="active">Blackbox</li>
                </ol>
            </div>-->
          </div>
          <div class="row">
            <div class="col-md-12">
              <div class="heading-title">
                <h2> <span>RedRock Life</span> <span class="text-yellow">.</span></h2>
              </div>
              <div class="row">
                <!-- begin:product-image-slider -->
                <div class="col-md-6 col-sm-6">
                  <div id="product-single" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                      <div class="item active">
                        <div class="product-single">
                          <img src="images/16.png" class="img-responsive">
                        </div>
                      </div>
                      <div class="item">
                        <div class="product-single">
                          <img src="images/16.png" class="img-responsive">
                        </div>
                      </div>
                      <div class="item">
                        <div class="product-single">
                          <img src="images/16.png" class="img-responsive">
                        </div>
                      </div>
                    </div>

                    <a class="left carousel-control" href="#product-single" data-slide="prev">
                      <i class="fa fa-angle-left"></i>
                    </a>
                    <a class="right carousel-control" href="#product-single" data-slide="next">
                      <i class="fa fa-angle-right"></i>
                    </a>
                  </div>
                </div>
                <!-- end:product-image-slider -->

                <!-- begin:product-spesification -->
                <div class="col-md-6 col-sm-6">
                  <div class="single-desc">
                    <form>
                      <span class="visible-xs">
                          <strong>Blackbox / AF0012 / In Stock</strong>
                      </span>

                      <table>
                        <tbody>
                          <tr class="hidden-xs">
                              <td><strong>Name</strong></td>
                              <td>:</td>
                              <td>Ginseng</td>
                          </tr>
                          <!--<tr class="hidden-xs">
                              <td><strong>Product Code</strong></td>
                              <td>:</td>
                              <td>AF0012</td>
                          </tr>-->
                          <tr class="hidden-xs">
                              <td><strong>Availability</strong></td>
                              <td>:</td>
                              <td>In Stock</td>
                          </tr>
                          <tr>
                              <td colspan="3"><!--<span class="price-old">$32.91</span>--> <span class="price">$21.42</span></td>
                          </tr>
                          <tr >
                              <td><strong>Quantity</strong></td>
                              <td>:</td>
                              <td >
                                <select class="form-control ccccc"">
                                  <option>10</option>
                                  <option>30</option>
                                  <option>60</option>
                                  
                                </select>
                            </td>   
                          </tr>
                          <tr >
                              <!--<td><strong>Size</strong></td>
                              <td>:</td>
                              <td>
                                <select class="form-control ccccc"">
                                  <option>XS</option>
                                  <option>S</option>
                                  <option>M</option>
                                  <option>L</option>
                                  <option>XL</option>
                                </select>
                              </td>
                          </tr>
                          <tr>
                              <td><strong>Quantity</strong></td>
                              <td>:</td>
                              <td class="">
                                <input type="text" class="form-control cccccc " value="1">
                              </td>
                          </tr>-->
                          <tr>
                              <td colspan="3">
                                <a class="butonss" href="#">Add to cart</a>
                              </td>  
                          </tr>
                        </tbody>
                      </table>
                    </form>
                  </div>
                </div>
                <!-- end:product-spesification -->
              </div>
              <!-- break -->
              <!-- begin:product-detail -->
              <div class="row">
                <div class="col-md-12 content-detail">
                    <ul id="myTab" class="nav nav-tabs">
                      <li class="active"><a href="#desc" data-toggle="tab">Description</a></li>
                      <!--<li class=""><a href="#care" data-toggle="tab">Care</a></li>
                      <li class=""><a href="#size" data-toggle="tab">Sizing</a></li>-->
                    </ul>

                    <div id="myTabContent" class="tab-content">
                      <div class="tab-pane fade active in" id="desc">
                        <p>RedRock Life, the perfect cobination of Cayanne, Cinnamon, Ginger, Ginseng, Milk Thistle, and Lecithin. 
  Our ingredients are only the highest quality, and after taking 10 you will feel the differnce. Try some today.</p>
                      </div>
                      <div class="tab-pane fade" id="care">
                        <p>Food truck fixie locavore, accusamus mcsweeney's marfa nulla single-origin coffee squid. Exercitation +1 labore velit, blog sartorial PBR leggings next level wes anderson artisan four loko farm-to-table craft beer twee. Qui photo booth letterpress, commodo enim craft beer mlkshk aliquip jean shorts ullamco ad vinyl cillum PBR.</p>
                      </div>
             
                    </div>
                </div>
              </div>
              <!-- end:product-detail -->

              <!-- begin:related-product -->
             
              <!-- end:related-product -->

            </div>
          </div>
        </div>
		        <!-- begin:sidebar -->
        <div class="col-md-3 col-sm-4 sidebar">
          <div class="row">
            <div class="col-md-12">
              <div class="widget cartbal">
                <div class="widget-title">
                  <h3>Cart</h3>
                </div>
                <ul class="cart list-unstyled">
                  <li class="cartr">
                    <div class="row">
                      <div class="col-sm-7 col-xs-7 cg ">1 <a href="">Ginseng</a> <span>[ 26 ]</span></div>
                      <div class="col-sm-5 col-xs-5 text-right cg"><strong class="cg">$54.00</strong> <a href="#"><i class="fa fa-trash-o"></i></a></div>
                    </div>
                  </li>
                  <li>
                    <div class="row">
                      <div class="col-sm-7 col-xs-7 cg">1 <a href="product_detail.html">Ginseng</a> <span>[ M ]</span></div>
                      <div class="col-sm-5 col-sm-5 text-right cg"><strong class="cg">$26.00</strong> <a href="#"><i class="fa fa-trash-o"></i></a></div>
                    </div>
                  </li>
                </ul>
                <ul class="list-unstyled total-price">
                    <li>
                      <div class="row ">
                        <div class="col-sm-8 col-xs-8 cg ">Shipping</div>
                        <div class="col-sm-4 col-xs-4 text-right cg">$1.00</div>
                      </div>
                    </li>
                    <li>
                      <div class="row cartr">
                        <div class="col-sm-8 col-xs-8 cg">Total</div>
                        <div class="col-sm-4 col-xs-4 text-right cg">$71.00</div>
                      </div>
                    </li>
                    <li>
                      <div class="row">
                        <div class="col-sm-6 col-xs-6">
                         <a class="butons" href="#">cart</a>
                        </div>
                        <div class="col-sm-6 col-xs-6 text-right">
                          <a class="butons" href="#">checkout</a>
                        </div>
                      </div>
                    </li>
                </ul>
              </div>
              <!-- break 
              <div class="widget">
                <div class="widget-title">
                  <h3>Category</h3>
                </div>
                <ul class="nav nav-pills nav-stacked">
                    <li class="active"><a href="#">Acessories</a></li>
                    <li><a href="#">Girl</a></li>
                    <li><a href="#">Boy</a></li>
                    <li><a href="#">Edition</a></li>
                </ul>
              </div>-->
              <!-- break -->
              <div class="widget payment">
                <div class="widget-title">
                  <h3>Payment Confirmation</h3>
                </div>
                <p><span>Already make a payment ?</span> please confirm your payment by filling <a href="confirm.html">this form</a></p>
              </div>

            </div>
          </div>
        </div>
        <!-- end:sidebar -->
        <!-- end:content -->
      </div>
					</div>
				</div>
       		<section class="products-list">			
			<div class="container">
			<!-- Heading Starts -->
				<h2 class="product-head">Related Products</h2>
			<!-- Heading Ends -->
			<!-- Products Row Starts -->
				<div class="row">
				<!-- Product #1 Starts -->
					<div class="col-md-3 col-sm-6">
						<div class="product-col">
							<div class="image">
								<img src="images/16.png" alt="product" class="img-responsive" />
							</div>
							<div class="caption">
								<h4><a href="product.html">Pills</a></h4>
								<div class="description">
									This pill has cayanne as the main ingredient, it also contains cinnamon, milk thistle, and lecithin
								</div>
								<div class="price">
									<span class="price-new">$27.95</span> 
									<!--<span class="price-old">$249.50</span>-->
								</div>
								<div class="cart-button button-group">
									<button type="button" title="Wishlist" class="btn btn-wishlist">
										<i class="fa fa-heart"></i>
									</button>
									<button type="button" title="Compare" class="btn btn-compare">
										<i class="fa fa-bar-chart-o"></i>
									</button>
									<button type="button" class="btn btn-cart">
										Add to cart
										<i class="fa fa-shopping-cart"></i> 
									</button>									
								</div>
							</div>
						</div>
					</div>
				<!-- Product #1 Ends -->
				<!-- Product #2 Starts -->
					<div class="col-md-3 col-sm-6">
						<div class="product-col">
							<div class="image">
								<img src="images/16.png" alt="product" class="img-responsive" />
							</div>
							<div class="caption">
								<h4><a href="product.html">Pills</a></h4>
								<div class="description">
									This pill has cayanne as the main ingredient, it also contains cinnamon, milk thistle, and lecithin
								</div>
								<div class="price">
									<span class="price-new">$27.95</span> 
									<!--<span class="price-old">$249.50</span>-->
								</div>
								<div class="cart-button button-group">
									<button type="button" title="Wishlist" class="btn btn-wishlist">
										<i class="fa fa-heart"></i>
									</button>
									<button type="button" title="Compare" class="btn btn-compare">
										<i class="fa fa-bar-chart-o"></i>
									</button>
									<button type="button" class="btn btn-cart">
										Add to cart
										<i class="fa fa-shopping-cart"></i> 
									</button>									
								</div>
							</div>
						</div>
					</div>
				<!-- Product #2 Ends -->
				<!-- Product #3 Starts -->
					<div class="col-md-3 col-sm-6">
						<div class="product-col">
							<div class="images">
								<img src="images/fun.jpg" alt="product" class="img-responsive" />
							</div>
							<div class="caption">
								<h4><a href="product.html">necklace</a></h4>
								<div class="description">
									This pill has cayanne as the main ingredient, it also contains cinnamon, milk thistle, and lecithin
								</div>
								<div class="price">
									<span class="price-new">$27.95</span> 
									<!--<span class="price-old">$249.50</span>-->
								</div>
								<div class="cart-button button-group">
									<button type="button" title="Wishlist" class="btn btn-wishlist">
										<i class="fa fa-heart"></i>
									</button>
									<button type="button" title="Compare" class="btn btn-compare">
										<i class="fa fa-bar-chart-o"></i>
									</button>
									<button type="button" class="btn btn-cart">
										Add to cart
										<i class="fa fa-shopping-cart"></i> 
									</button>									
								</div>
							</div>
						</div>
					</div>
				<!-- Product #3 Ends -->
				<!-- Product #4 Starts -->
					<div class="col-md-3 col-sm-6">
						<div class="product-col">
							<div class="image">
								<img src="images/1.jpg" alt="product" class="img-responsive" />
							</div>
							<div class="caption">
								<h4><a href="product.html">goat milk soap</a></h4>
								<div class="description">
									This pill has cayanne as the main ingredient, it also contains cinnamon, milk thistle, and lecithin
								</div>
								<div class="price">
									<span class="price-new">$27.95</span> 
									<!--<span class="price-old">$249.50</span>-->
								</div>
								<div class="cart-button button-group">
									<button type="button" title="Wishlist" class="btn btn-wishlist">
										<i class="fa fa-heart"></i>
									</button>
									<button type="button" title="Compare" class="btn btn-compare">
										<i class="fa fa-bar-chart-o"></i>
									</button>
									<button type="button" class="btn btn-cart">
										Add to cart
										<i class="fa fa-shopping-cart"></i> 
									</button>									
								</div>
							</div>
						</div>
					</div>
				<!-- Product #4 Ends -->
				</div>
			<!-- Products Row Ends -->
			</div>
		</section>

</div>

		<!-- Footer -->
		<?php include 'footer.php'
	?>
		

	</body>
</html>
