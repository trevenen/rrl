<!DOCTYPE HTML>
<html>
<head>
	<?php include 'header.php'
	?>
	
	

	<!-- Nav -->
		<?php include 'menu.php'
	?>
	</div>
			
<!-- Banner -->
	<section id="banner">
		<header class="homepage">
                </br>
			<h2 class="container special">About Us</h2>
		</header>
	  </section>

<!-- Main -->
<!-- Necklace Product. -->

<div class="wrapper style2">
        <article id="main" class="container special">
        
                
                <p>RedRock Life has been around since 2010 in one form or an other, it all started when Mr. Red's wife was feelling sick and tired. Not a normal sick and tired, but throuroughly tired, tired to the core. Well Mr. Red started researching chinese medicens and found out that when peoples bodys are tired they are not in harmony with life, energy, and God. Generally speaking, the standardized applications of Chinese herbs began since the publishing of Shang Han Lun and Jin Gui Yao Lue, The Treatise on Cold Damage Disorders and Miscellaneous Illnesses, collated by Zhang Zhongjing, who is deemed as the founding father of Classic Formulas. This book can date back to the end of the Han dynasty, almost two thousands years ago.
Unlike western medicine is developed around a basic theory, the method of pattern diagnosis is way much different. Without the help of modern machines, it is virtually impossible for ancients to know the true nature of pathological changes. What they could lay hand on was the visible and touchable symptoms and signs, which more often than not would lead them to the false belief that these superficial phenomena is the pathogenesis of the diseases. But now we already know that they are not
Since this method is so rough, does it really work? That is the most frequently asked question in terms of herbal healing. Apparently it must to be answered well before obtaining the confidence.
Picture the harsh condition in the primitive times. Lacking of crops cultivation techniques, they could do nothing but hunting animals or gathering plants to survive. This is such a long-term process of trial and error that can barely imagine by person who is living a modern city life. It was learned the hard way, even costs a lot of deaths to trade for some revelation. There would be a long and flat learning curve, and they might make terrible mistakes to tell which wild fruits, seeds and tuber were edible and curative. However, that wisdom is not born with but acquired.
After reading many Chinese books and learning and experimenting with different American Herbs, Mr. Red put Cayanne Pepper, Ginger, Ginseng, Milk Thistle, and Lecithin together to create the first and original RedRock Life Capsule. It was beautiful, a mix of these herbs some from his own garden and some from trusted Herbal Suppliers. 
Slowly Mr and Mrs. Red started sharing theme with each other and would always tell people use more cayanne pepper in your foods, stop eating black pepper completely and switch to cayenne! 
For the 4 years, Mr and Mrs. Red didn't get sick, they were not as tired, and they just felt better. They saw others who were sick, who were tired, they suggested hey just try some cayanne pepper it will help, but many Americans  </p>
               
      
<!--
         <footer>
                <a href="#" class="button">View Necklaces</a>
        </footer>
-->
        </article>

</div>



<!-- Footer -->
<?php include 'footer.php'
	?>
</body>
</html>
