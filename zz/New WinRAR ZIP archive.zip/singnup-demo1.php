<!DOCTYPE HTML>
<html>
   <head>
      <?php include 'header.php'
	?>
		<?php include 'menu.php'
	?>
		
      </div>
      <!-- Main -->
      <div class="wrapper style1">
         <div class="container">
            <div class="row 200%">
               <div class="8u" id="content">
                  <div class="page-wrapper">
                     <main role="main" class="page-content">
                        <section class="section">
                           <div class="">
                              <header class="text-center">
                                 <h1 class="giga heading-font sal ">Sign Up</h1>
                              </header>
                              <div class="wpcf7" id="wpcf7-f133-o1" dir="ltr">
                                 <div class="screen-reader-response"></div>
                                 <form name="" action="" method="post" class="wpcf7-form" novalidate="novalidate">
                                    <div style="display: none;">
                                       <input type="hidden" name="_wpcf7" value="133" />
                                       <input type="hidden" name="_wpcf7_version" value="4.1" />
                                       <input type="hidden" name="_wpcf7_locale" value="" />
                                       <input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f133-o1" />
                                       <input type="hidden" name="_wpnonce" value="e9875e756c" />
                                    </div>
                                    <div class="wpcf7-response-output wpcf7-display-none "></div>
                                    <ul class="form-lists">
                                       <li class="form-list__items"><input type="text" name="your-name" value="" size="40" required="required" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required input" aria-required="true" aria-invalid="false" /></span><label class="input__label lift">Your Name</label></li>
                                       <li class="form-list__items"><input type="text" name="company-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required input" aria-required="true" aria-invalid="false" /></span><label class="input__label lift">Company Name</label></li>
                                       <li class="form-list__items"><input type="email" name="email-address" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email input" aria-required="true" aria-invalid="false lift" /></span><label class="input__label lift">Email Address</label></li>
                                       <li class="form-list__items"><input type="text" name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required input" aria-required="true" aria-invalid="false" /></span><label class="input__label lift">Phone Number</label></li>
                                       <li class="form-list__items"><input type="password" name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required input" aria-required="true" aria-invalid="false" /></span><label class="input__label lift">Password</label></li>
                                       <li class="form-list__items"><input type="password" name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required input" aria-required="true" aria-invalid="false" /></span><label class="input__label lift">Re-type Password</label></li>
                                       <li class="form-list__items"><p class="boll"><span>*</span>We will never share your information.</p></li>
                                       
                                       <li class="form-list__item form-list--button"><button ID="buttons" type="submit" name="submit">Sign Up</button></li>
                                    </ul>
                                 </form>
                              </div>
                           </div>
                        </section>
                     </main>
                  </div>
               </div>
               <div class="4u" id="sidebar">
                  <hr class="first" />
                  <section>
                     <header>
                        <h3><a href="#">Accumsan sed penatibus</a></h3>
                     </header>
                     <p>
                        Dolor sed fringilla nibh nulla convallis tique ante proin sociis accumsan lobortis. Auctor etiam
                        porttitor phasellus tempus cubilia ultrices tempor sagittis  tellus ante diam nec penatibus dolor cras
                        magna tempus feugiat veroeros.
                     </p>
                     <footer>
                        <a href="#" class="button">Learn More</a>
                     </footer>
                  </section>
                  <hr />
                  <section>
                     <header>
                        <h3><a href="#">Sed lorem etiam consequat</a></h3>
                     </header>
                     <p>
                        Tempus cubilia ultrices tempor sagittis. Nisl fermentum consequat integer interdum.
                     </p>
                     <div class="row 50% no-collapse">
                        <div class="4u">
                           <a href="#" class="image fit"><img src="images/pic10.jpg" alt="" /></a>
                        </div>
                        <div class="8u">
                           <h4>Nibh sed cubilia</h4>
                           <p>
                              Amet nullam fringilla nibh nulla convallis tique ante proin.
                           </p>
                        </div>
                     </div>
                     <div class="row 50% no-collapse">
                        <div class="4u">
                           <a href="#" class="image fit"><img src="images/pic11.jpg" alt="" /></a>
                        </div>
                        <div class="8u">
                           <h4>Proin sed adipiscing</h4>
                           <p>
                              Amet nullam fringilla nibh nulla convallis tique ante proin.
                           </p>
                        </div>
                     </div>
                     <div class="row 50% no-collapse">
                        <div class="4u">
                           <a href="#" class="image fit"><img src="images/pic12.jpg" alt="" /></a>
                        </div>
                        <div class="8u">
                           <h4>Lorem feugiat magna</h4>
                           <p>
                              Amet nullam fringilla nibh nulla convallis tique ante proin.
                           </p>
                        </div>
                     </div>
                     <div class="row 50% no-collapse">
                        <div class="4u">
                           <a href="#" class="image fit"><img src="images/pic13.jpg" alt="" /></a>
                        </div>
                        <div class="8u">
                           <h4>Sed tempus fringilla</h4>
                           <p>
                              Amet nullam fringilla nibh nulla convallis tique ante proin.
                           </p>
                        </div>
                     </div>
                     <div class="row 50% no-collapse">
                        <div class="4u">
                           <a href="#" class="image fit"><img src="images/pic14.jpg" alt="" /></a>
                        </div>
                        <div class="8u">
                           <h4>Malesuada fermentum</h4>
                           <p>
                              Amet nullam fringilla nibh nulla convallis tique ante proin.
                           </p>
                        </div>
                     </div>
                     <footer>
                        <a href="#" class="button">Magna Adipiscing</a>
                     </footer>
                  </section>
               </div>
            </div>
            <hr />
            <div class="row">
               <article class="4u special">
                  <a href="#" class="image featured"><img src="images/pic07.jpg" alt="" /></a>
                  <header>
                     <h3><a href="#">Gravida aliquam penatibus</a></h3>
                  </header>
                  <p>
                     Amet nullam fringilla nibh nulla convallis tique ante proin sociis accumsan lobortis. Auctor etiam
                     porttitor phasellus tempus cubilia ultrices tempor sagittis. Nisl fermentum consequat integer interdum.
                  </p>
               </article>
               <article class="4u special">
                  <a href="#" class="image featured"><img src="images/pic08.jpg" alt="" /></a>
                  <header>
                     <h3><a href="#">Sed quis rhoncus placerat</a></h3>
                  </header>
                  <p>
                     Amet nullam fringilla nibh nulla convallis tique ante proin sociis accumsan lobortis. Auctor etiam
                     porttitor phasellus tempus cubilia ultrices tempor sagittis. Nisl fermentum consequat integer interdum.
                  </p>
               </article>
               <article class="4u special">
                  <a href="#" class="image featured"><img src="images/pic09.jpg" alt="" /></a>
                  <header>
                     <h3><a href="#">Magna laoreet et aliquam</a></h3>
                  </header>
                  <p>
                     Amet nullam fringilla nibh nulla convallis tique ante proin sociis accumsan lobortis. Auctor etiam
                     porttitor phasellus tempus cubilia ultrices tempor sagittis. Nisl fermentum consequat integer interdum.
                  </p>
               </article>
            </div>
         </div>
      </div>
      <!-- Footer -->
<?php include 'footer.php'
	?>
		
	  <script>



( function( window ) {

'use strict';



function classReg( className ) {
  return new RegExp("(^|\\s+)" + className + "(\\s+|$)");
}


var hasClass, addClass, removeClass;

if ( 'classList' in document.documentElement ) {
  hasClass = function( elem, c ) {
    return elem.classList.contains( c );
  };
  addClass = function( elem, c ) {
    elem.classList.add( c );
  };
  removeClass = function( elem, c ) {
    elem.classList.remove( c );
  };
}
else {
  hasClass = function( elem, c ) {
    return classReg( c ).test( elem.className );
  };
  addClass = function( elem, c ) {
    if ( !hasClass( elem, c ) ) {
      elem.className = elem.className + ' ' + c;
    }
  };
  removeClass = function( elem, c ) {
    elem.className = elem.className.replace( classReg( c ), ' ' );
  };
}

function toggleClass( elem, c ) {
  var fn = hasClass( elem, c ) ? removeClass : addClass;
  fn( elem, c );
}

var classie = {
  // full names
  hasClass: hasClass,
  addClass: addClass,
  removeClass: removeClass,
  toggleClass: toggleClass,
  // short names
  has: hasClass,
  add: addClass,
  remove: removeClass,
  toggle: toggleClass
};

// transport
if ( typeof define === 'function' && define.amd ) {
  // AMD
  define( classie );
} else {
  // browser global
  window.classie = classie;
}

})( window );
</script>
<!--Form transitions-->
		<script>
			(function() {
			
				if (!String.prototype.trim) {
					(function() {
						// Make sure we trim BOM and NBSP
						var rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
						String.prototype.trim = function() {
							return this.replace(rtrim, '');
						};
					})();
				}

				[].slice.call( document.querySelectorAll( '.input' ) ).forEach( function( inputEl ) {
					// in case the input is already filled..
					if( inputEl.value.trim() !== '' ) {
						classie.add( inputEl, 'input--filled' );
					}

					// events:
					inputEl.addEventListener( 'focus', onInputFocus );
					inputEl.addEventListener( 'blur', onInputBlur );
				} );

				function onInputFocus( ev ) {
					classie.add( ev.target, 'input--filled' );
				}

				function onInputBlur( ev ) {
					if( ev.target.value.trim() === '' ) {
						classie.remove( ev.target, 'input--filled' );
					}
				}
			})();
		</script>

<!--Activating the popup-->
	<script>

$(function(){
    $('#pop').click(function(){
        $('#popup').bPopup({
            speed: 650,
			
            transition: 'slideIn',
	    transitionClose: 'slideIn'
        });
    });
});
</script>	
   </body>
</html>
